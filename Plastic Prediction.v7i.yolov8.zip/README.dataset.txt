# Plastic Prediction > 2025-06-01 7:47pm
https://universe.roboflow.com/kayalmachinelearningworkspace/plastic-prediction

Provided by a Roboflow user
License: CC BY 4.0

